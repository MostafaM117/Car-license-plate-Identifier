# car plates Identifier > 2025-05-05 3:31pm
https://universe.roboflow.com/mostafa-mohamed-xgppt/car-plates-identifier

Provided by a Roboflow user
License: CC BY 4.0

